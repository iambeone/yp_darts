import React from "react";
import PageTitle from "../../components/PageTitle/PageTitle";

export default function ProtocolsPage() {
  return (
    <div>
      <PageTitle title="ProtocolsPage" />
    </div>
  );
}

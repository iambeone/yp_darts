import React from "react";
import PageTitle from "../../components/PageTitle/PageTitle";

export default function HomePage() {
  return (
    <div>
      <PageTitle title="Start App" />
    </div>
  );
}

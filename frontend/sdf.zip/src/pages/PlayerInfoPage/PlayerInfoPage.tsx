import React from "react";
import PageTitle from "../../components/PageTitle/PageTitle";

export default function PlayerInfoPage() {
  return (
    <>
      <PageTitle title="Игроки" />
      <div>Info</div>
    </>
  );
}

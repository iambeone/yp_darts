import React from "react";
import PageTitle from "../../components/PageTitle/PageTitle";

export default function ProfilePage() {
  return (
    <div>
      <PageTitle title="ProfilePage" />
    </div>
  );
}

import React from "react";
import PageTitle from "../../components/PageTitle/PageTitle";

export default function NotFound404() {
  return (
    <div>
      <PageTitle title="Not Found" />
    </div>
  );
}

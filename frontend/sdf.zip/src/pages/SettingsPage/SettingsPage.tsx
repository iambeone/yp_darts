import React from "react";
import PageTitle from "../../components/PageTitle/PageTitle";

export default function SettingsPage() {
  return (
    <div>
      <PageTitle title="SettingsPage" />
    </div>
  );
}

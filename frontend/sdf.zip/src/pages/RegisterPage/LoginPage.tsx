import React from "react";
import PageTitle from "../../components/PageTitle/PageTitle";

export default function LoginPage() {
  return (
    <div>
      <PageTitle title="LoginPage" />
    </div>
  );
}

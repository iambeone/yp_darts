import MainForm from "./MainForm";
import DocumentsForm from "./DocumentsForm";
import GameInfoForm from "./GameInfoForm";
import AdditionalForm from "./AdditionalForm";

export { MainForm, DocumentsForm, GameInfoForm, AdditionalForm };
